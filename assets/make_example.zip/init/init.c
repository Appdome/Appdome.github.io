#include <popup/popup.h>

static void __attribute__((constructor)) init(void)
{
	show_popup(POPUP_TITLE, POPUP_CONTENTS);
}