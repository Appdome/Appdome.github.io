#include <UIKit/UIKit.h>
#include "popup.h"

void show_popup(const char *title, const char *contents)
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@(title)
													message:@(contents)
												   delegate:nil 
										  cancelButtonTitle:@"Close"
										  otherButtonTitles:nil];
	[alert show];
}
