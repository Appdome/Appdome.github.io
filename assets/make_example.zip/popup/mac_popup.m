#include <AppKit/AppKit.h>
#include "popup.h"

void show_popup(const char *title, const char *contents)
{
	NSAlert *alert = [[NSAlert alloc] init];
	[alert setMessageText:@(title)];
	[alert setInformativeText:@(contents)];
	[alert addButtonWithTitle:@"Close"];
	[alert runModal];
}
