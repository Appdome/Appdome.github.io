#pragma once

void show_popup(const char *title, const char *contents);
