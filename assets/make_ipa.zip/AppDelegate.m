#include <UIKit/UIKit.h>
#include "AppDelegate.h"

@implementation AppDelegate
{
    /* We must retain a reference to our window to keep it visible */
    UIWindow *window;
}

- (BOOL)application:(UIApplication *)application
didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    CGRect screen = [[UIScreen mainScreen] bounds];
    window = [[UIWindow alloc] initWithFrame:screen];
    window.rootViewController = [[UIViewController alloc] init];
    window.backgroundColor = [UIColor whiteColor]; /* Give the window a non-transparent background */
    [window makeKeyAndVisible];
    return YES;
}
@end