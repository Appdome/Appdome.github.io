#include <UIKit/UIKit.h>

@interface AppDelegate: UIResponder <UIApplicationDelegate>
@end